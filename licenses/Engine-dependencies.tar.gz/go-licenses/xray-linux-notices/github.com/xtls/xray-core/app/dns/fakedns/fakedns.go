package fakedns
